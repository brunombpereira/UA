import socket
import threading
import random

# Configuration
HOST = '127.0.0.1'  # Localhost
PORT = 65432        # Arbitrary non-privileged port
clients_data = {}   # Tracks attempts for each client

def handle_client(conn, addr):
    """Handle a single client connection."""
    try:
        conn.sendall(b"Welcome to the Guess the Number game!\n")
        
        # Receive player's name
        conn.sendall(b"Enter your name: ")
        player_name = conn.recv(1024).decode().strip()
        if not player_name:
            conn.sendall(b"Invalid name. Connection closing.\n")
            return

        # Assign a random number to guess
        number_to_guess = random.randint(1, 100)
        attempts = 0
        client_key = f"{addr[0]}:{addr[1]}:{player_name}"
        clients_data[client_key] = attempts

        conn.sendall(b"Guess a number between 1 and 100.\n")

        while True:
            guess = conn.recv(1024).decode().strip()
            if not guess.isdigit():
                conn.sendall(b"Please enter a valid number.\n")
                continue
            
            guess = int(guess)
            attempts += 1
            clients_data[client_key] = attempts

            if guess < number_to_guess:
                conn.sendall(b"Higher!\n")
            elif guess > number_to_guess:
                conn.sendall(b"Lower!\n")
            else:
                conn.sendall(f"Correct! You guessed it in {attempts} attempts.\n".encode())
                break
    except Exception as e:
        print(f"Error handling client {addr}: {e}")
    finally:
        print(f"Client {addr} disconnected.")
        conn.close()

def start_server():
    """Start the server and listen for clients."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((HOST, PORT))
        server_socket.listen()
        print(f"Server started on {HOST}:{PORT}")

        while True:
            conn, addr = server_socket.accept()
            print(f"New connection from {addr}")
            threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()

if __name__ == "__main__":
    start_server()

