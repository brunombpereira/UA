
import socket

# Configuration
SERVER_HOST = '127.0.0.1'  # Server address
SERVER_PORT = 65432        # Server port

def start_client():
    """Start the client to play the game."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        client_socket.connect((SERVER_HOST, SERVER_PORT))

        while True:
            message = client_socket.recv(1024).decode()
            print(message, end="")  # Print server message
            
            if "Correct!" in message:
                break  # End game if correct guess
            
            # Input guess or name
            user_input = input()
            client_socket.sendall(user_input.encode())

if __name__ == "__main__":
    start_client()
